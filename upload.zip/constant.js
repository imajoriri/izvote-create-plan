exports.constant = {
  shopsMaxLength: 15,
}
