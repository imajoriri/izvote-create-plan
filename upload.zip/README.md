# 決まりごと

1. `console.log`は`indexjs`にのみ
2. レスポンスの`status`は"ok"か"err"のどちらか
3. 関数内でのエラー処理は考えない。index.jsで行う
